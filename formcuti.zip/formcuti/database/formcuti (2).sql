-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2019 at 11:27 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `formcuti`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_cut`
--

CREATE TABLE `form_cut` (
  `id_cuti` varchar(50) NOT NULL,
  `tgl` date NOT NULL,
  `nik` varchar(50) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `lama_cuti` int(50) NOT NULL,
  `sisa_cuti` int(50) NOT NULL,
  `alamat_cuti` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_cut`
--

INSERT INTO `form_cut` (`id_cuti`, `tgl`, `nik`, `jenis`, `tanggal_mulai`, `tanggal_akhir`, `lama_cuti`, `sisa_cuti`, `alamat_cuti`) VALUES
('IC0001', '2019-06-24', '88', 'cuti tahunan', '2019-06-14', '2019-06-14', 3, 9, 'JAKARTA'),
('IC0002', '2019-06-24', '666', 'cuti sakit', '2019-06-03', '2019-06-03', 1, 11, 'JAKARTA\n'),
('IC0003', '2019-06-24', '555', 'cuti tahunan', '2019-06-07', '2019-06-05', 2, 10, 'BOGOR'),
('IC0004', '2019-06-24', '666', 'cuti sakit', '2019-06-02', '2019-06-04', 2, 10, 'BOGOR');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `nik` int(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenkel` varchar(501) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `cuti_t` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`nik`, `nama`, `jenkel`, `alamat`, `jabatan`, `cuti_t`) VALUES
(111, 'reyhan', 'laki-laki', 'jl kenanga', 'karyawan', '12'),
(222, 'siska', 'perempuan', 'jl delima', 'karyawan', '12'),
(555, 'jesica', 'perempuan', 'jl jambu', 'manager', '12');

-- --------------------------------------------------------

--
-- Table structure for table `koordinator`
--

CREATE TABLE `koordinator` (
  `idk` varchar(50) NOT NULL,
  `nmk` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tlp` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `koordinator`
--

INSERT INTO `koordinator` (`idk`, `nmk`, `email`, `tlp`) VALUES
('111', 'rizky', 'rizky@gmail.com', 896778067),
('222', 'rafi', 'rafi@gmail.com', 89653789),
('333', 'rama', 'rama@gmail.com', 876980765),
('555', 'dodi', 'dodi@gmail.com', 876549876);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('selvi', 12345),
('rama', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `persetujuan`
--

CREATE TABLE `persetujuan` (
  `id_form` varchar(10) NOT NULL,
  `tgl` date NOT NULL,
  `id_cuti` varchar(50) NOT NULL,
  `id_koordinator` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Baru',
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `persetujuan`
--

INSERT INTO `persetujuan` (`id_form`, `tgl`, `id_cuti`, `id_koordinator`, `nama`, `status`, `keterangan`) VALUES
('IP0001', '2019-06-25', 'IC0004', '222', 'rafi', 'REJECT', 'eh BANGSAD UDAH GW BILANG SIBUK NJING!!!!'),
('IP0002', '2019-06-25', 'IC0003', '333', 'rama', 'APPROVE', '-'),
('IP0003', '2019-06-25', 'IC0004', '111', 'rizky', 'APPROVE', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_cut`
--
ALTER TABLE `form_cut`
  ADD PRIMARY KEY (`id_cuti`) USING BTREE;

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `koordinator`
--
ALTER TABLE `koordinator`
  ADD PRIMARY KEY (`idk`);

--
-- Indexes for table `persetujuan`
--
ALTER TABLE `persetujuan`
  ADD PRIMARY KEY (`id_form`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
